let progress = 0;
function updateProgress() {
    if (progress < 100) {
        progress += Math.random() * 5 + 2; // Ajoute une progression aléatoire plus fluide
        if (progress > 100) progress = 100;
        document.getElementById("progress").style.width = progress + "%";
    }
    setTimeout(updateProgress, 1000); // Mise à jour toutes les secondes pour plus de fluidité
}
updateProgress();
